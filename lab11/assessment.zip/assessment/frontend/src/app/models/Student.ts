export class Student {
    name: string;
    age: number;
    fees: number;

    constructor () {
        this.name = ''
        this.age = 0
        this.fees = 0
    }
}