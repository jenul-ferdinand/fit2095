//develop a class called Student with three attributes: name age and fees
class Student{
    constructor(name, age, fees){
        this.name = name;
        this.age = age;
        this.fees = fees;
    }
}

module.exports = Student;
