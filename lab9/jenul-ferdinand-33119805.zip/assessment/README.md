# Assessment

Assuming "1. Your name and student ID should be in the name of the project." means changing name in `package.json` and/or changing the file name to my name and student ID.
