// Model for a PC
export class PC {
    CPU: String;
    RAM: String;
    HDD: String;
    
    constructor() {
        this.CPU = '';
        this.RAM = '';
        this.HDD = '';
    }
}